package com.fiserv.interviews.challenge.service;

import com.fiserv.interviews.challenge.entity.TransactionVo;
import org.springframework.stereotype.Service;

@Service
public class FraudService {

	public boolean isFraud(final TransactionVo transaction) {
		throw new UnsupportedOperationException("Method not implemented");
	}
}
